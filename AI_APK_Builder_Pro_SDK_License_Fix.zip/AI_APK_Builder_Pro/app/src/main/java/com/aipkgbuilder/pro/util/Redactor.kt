package com.aipkgbuilder.pro.util

object Redactor {
    private val wholeSecretPatterns = listOf(
        Regex("(?i)gh[pousr]_[A-Za-z0-9_]{20,}"),
        Regex("(?i)github_pat_[A-Za-z0-9_]{20,}"),
        Regex("(?i)AIza[0-9A-Za-z_-]{20,}"),
        Regex("-----BEGIN [A-Z ]*PRIVATE KEY-----[\\s\\S]*?-----END [A-Z ]*PRIVATE KEY-----")
    )
    private val prefixedPatterns = listOf(
        Regex("(?i)(x-goog-api-key\\s*[:=]\\s*)[^\\s,]+"),
        Regex("(?i)(authorization\\s*[:=]\\s*(?:bearer|token)\\s+)[^\\s,]+"),
        Regex("(?i)((?:api[_-]?key|access[_-]?token|client[_-]?secret|password|signingConfigPassword)\\s*[:=]\\s*)[^\\s,;]+")
    )

    fun redact(input: String): String {
        var output = input
        wholeSecretPatterns.forEach { pattern -> output = pattern.replace(output, "[REDACTED SECRET]") }
        prefixedPatterns.forEach { pattern ->
            output = pattern.replace(output) { match -> (match.groups[1]?.value ?: "") + "[REDACTED]" }
        }
        return output
    }
}
