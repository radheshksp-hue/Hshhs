package com.aipkgbuilder.pro.github

import android.content.Context
import com.aipkgbuilder.pro.security.SecureSecrets
import com.aipkgbuilder.pro.util.Redactor
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import okio.BufferedSink
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.net.URLEncoder
import java.nio.charset.StandardCharsets
import java.util.concurrent.TimeUnit

private const val API_BASE = "https://api.github.com"
private const val API_VERSION_DEFAULT = "2026-03-10"

class GitHubApiException(val statusCode: Int, message: String) : IOException("GitHub API ($statusCode): ${Redactor.redact(message).take(800)}")
class WorkflowOverwriteRequired : IOException("A different build-apk.yml already exists. Review it and confirm replacement before continuing.")

data class GitHubSettings(val owner: String, val repository: String, val branch: String = "main") {
    val fullName: String get() = "$owner/$repository"
    fun validate() {
        require(owner.matches(Regex("[A-Za-z0-9-]{1,39}"))) { "Enter a valid GitHub owner name." }
        require(repository.matches(Regex("[A-Za-z0-9_.-]{1,100}")) && repository != "." && repository != "..") { "Enter a valid repository name." }
        require(branch.isNotBlank() && branch.length <= 255 && !branch.startsWith("-") && !branch.contains("..")) { "Enter a valid default branch." }
    }
}

data class GitHubConnection(val login: String, val repoFullName: String, val isPrivate: Boolean, val canPush: Boolean, val defaultBranch: String, val remainingRateLimit: Int?)
data class PublishedBuildRelease(val tag: String, val releaseId: Long, val releaseUrl: String, val assetId: Long, val assetSize: Long)
data class WorkflowRunState(
    val runId: Long,
    val status: String,
    val conclusion: String?,
    val runUrl: String,
    val displayTitle: String,
    val createdAt: String?,
    val currentStep: String? = null,
    val steps: List<WorkflowStep> = emptyList()
)
data class WorkflowStep(val name: String, val status: String, val conclusion: String?)
data class ArtifactInfo(val id: Long, val name: String, val sizeBytes: Long, val expired: Boolean)

data class WorkflowRunHeader(
    val runId: Long,
    val status: String,
    val conclusion: String?,
    val runUrl: String,
    val displayTitle: String,
    val createdAt: String?
)

/** Pure parser for actual GitHub Actions REST run records. */
object WorkflowRunParser {
    fun parse(run: JSONObject): WorkflowRunHeader = WorkflowRunHeader(
        runId = run.optLong("id", -1L),
        status = run.optString("status", "unknown"),
        conclusion = run.optString("conclusion").takeIf { it.isNotBlank() && it != "null" },
        runUrl = run.optString("html_url"),
        displayTitle = run.optString("display_title", run.optString("name", "APK build")),
        createdAt = run.optString("created_at").takeIf { it.isNotBlank() && it != "null" }
    )
}

object BuildStateMapper {
    fun fromRemote(status: String, conclusion: String?): String = when {
        status != "completed" -> "IN_PROGRESS"
        conclusion == "success" -> "SUCCEEDED"
        else -> "FAILED"
    }
}


/** Direct GitHub REST client. Token values are never included in URLs or log messages. */
class GitHubClient(
    private val context: Context,
    private val settings: GitHubSettings,
    private val tokenOverride: String? = null,
    private val apiVersion: String = API_VERSION_DEFAULT
) {
    private val token: String by lazy { tokenOverride ?: SecureSecrets(context).get(SECRET_GITHUB_TOKEN).orEmpty() }
    private val http = OkHttpClient.Builder()
        .connectTimeout(25, TimeUnit.SECONDS)
        .readTimeout(120, TimeUnit.SECONDS)
        .writeTimeout(180, TimeUnit.SECONDS)
        .callTimeout(5, TimeUnit.MINUTES)
        .followRedirects(true)
        .followSslRedirects(true)
        .build()

    fun apiUrl(path: String): String = "$API_BASE${if (path.startsWith("/")) path else "/$path"}"

    suspend fun testConnection(): GitHubConnection {
        settings.validate()
        require(token.isNotBlank()) { "Enter a GitHub Personal Access Token first." }
        val user = getJson("/user")
        val repo = getJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}")
        val permissions = repo.optJSONObject("permissions")
        val privacy = repo.optBoolean("private", false)
        if (!privacy) throw IOException("The configured builder repository is not private. Builds are stopped to protect project source.")
        val rate = lastRateLimit
        return GitHubConnection(
            login = user.optString("login", "unknown"),
            repoFullName = repo.optString("full_name", settings.fullName),
            isPrivate = privacy,
            canPush = permissions?.optBoolean("push", false) ?: false,
            defaultBranch = repo.optString("default_branch", settings.branch),
            remainingRateLimit = rate
        )
    }

    @Volatile private var lastRateLimit: Int? = null

    suspend fun verifyRepository(): JSONObject {
        settings.validate()
        val repo = getJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}")
        if (!repo.optBoolean("private", false)) throw IOException("Builder repository must be private. Change visibility in GitHub settings before building.")
        val archived = repo.optBoolean("archived", false)
        if (archived) throw IOException("Builder repository is archived. Unarchive it before using the builder.")
        val permissions = repo.optJSONObject("permissions")
        if (permissions != null && !permissions.optBoolean("push", false)) {
            throw IOException("The token's account does not have push access to this repository. Grant minimum required Contents/Workflows write permissions.")
        }
        return repo
    }

    suspend fun installOrVerifyWorkflow(workflowText: String, overwriteDifferent: Boolean = false): String {
        val repo = verifyRepository()
        val branch = repo.optString("default_branch", settings.branch).ifBlank { settings.branch }
        val path = ".github/workflows/build-apk.yml"
        val existing = try {
            getJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/contents/${path.split('/').joinToString("/") { segment(it) }}?ref=${segment(branch)}")
        } catch (error: GitHubApiException) {
            if (error.statusCode == 404) null else throw error
        }
        if (existing != null) {
            val rawContent = runCatching {
                android.util.Base64.decode(existing.optString("content").replace("\n", ""), android.util.Base64.DEFAULT).toString(Charsets.UTF_8)
            }.getOrDefault("")
            if (rawContent == workflowText) return "Workflow already matches the bundled version on branch '$branch'."
            if (!overwriteDifferent) throw WorkflowOverwriteRequired()
        }
        val payload = JSONObject()
            .put("message", if (existing == null) "Add AI APK Builder Pro workflow" else "Update AI APK Builder Pro workflow")
            .put("content", android.util.Base64.encodeToString(workflowText.toByteArray(Charsets.UTF_8), android.util.Base64.NO_WRAP))
            .put("branch", branch)
        if (existing != null && existing.optString("sha").isNotBlank()) payload.put("sha", existing.optString("sha"))
        putJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/contents/${path.split('/').joinToString("/") { segment(it) }}", payload)
        return "Workflow installed/updated on '$branch'. GitHub may take a short time to register it."
    }

    suspend fun workflowExists(): Boolean {
        return try {
            getJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/contents/.github/workflows/build-apk.yml?ref=${segment(settings.branch)}")
            true
        } catch (error: GitHubApiException) {
            if (error.statusCode == 404) false else throw error
        }
    }

    suspend fun verifyActionsEnabled(): Boolean {
        val response = getJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/actions/permissions")
        return response.optBoolean("enabled", false)
    }

    suspend fun verifyRepositoryPermissions(): String {
        val repo = verifyRepository()
        val permissions = repo.optJSONObject("permissions")
        val push = permissions?.optBoolean("push", false) ?: false
        val actions = runCatching { verifyActionsEnabled() }.getOrNull()
        val workflowPresent = workflowExists()
        return buildString {
            appendLine("Repository: ${repo.optString("full_name")}")
            appendLine("Private: ${repo.optBoolean("private", false)}")
            appendLine("Push access: $push")
            appendLine("Workflow file: ${if (workflowPresent) "present" else "missing"}")
            appendLine("GitHub Actions enabled: ${actions?.toString() ?: "not verified (check Actions read permission)"}")
            if (!push) appendLine("Required: repository write access plus Contents: write and Workflows: write for installing workflows.")
            if (actions == false) appendLine("Enable Actions in the repository settings before starting a build.")
        }
    }

    suspend fun publishBuildRelease(sourceZip: File, tag: String, attempt: Int): PublishedBuildRelease {
        require(sourceZip.isFile && sourceZip.length() > 0L) { "Source ZIP is missing or empty." }
        if (!tag.matches(Regex("apkbuild-[a-z0-9-]{6,80}-attempt-[1-9][0-9]*"))) throw IOException("Unsafe or invalid build tag.")
        val repo = verifyRepository()
        val branch = repo.optString("default_branch", settings.branch).ifBlank { settings.branch }
        if (!workflowExists()) throw IOException("Build workflow is missing. Use Install / Update Build Workflow first.")
        val release = postJson(
            "/repos/${segment(settings.owner)}/${segment(settings.repository)}/releases",
            JSONObject()
                .put("tag_name", tag)
                .put("target_commitish", branch)
                .put("name", "APK build $tag")
                .put("body", "Temporary private source upload for AI APK Builder Pro. Attempt $attempt. Do not publish source elsewhere.")
                .put("draft", true)
                .put("prerelease", false)
        )
        val releaseId = release.optLong("id", -1L)
        if (releaseId <= 0L) throw IOException("GitHub created no verifiable release identifier.")
        try {
            val rawUploadUrl = release.optString("upload_url").substringBefore("{")
            if (!rawUploadUrl.startsWith("https://uploads.github.com/")) throw IOException("GitHub returned an unexpected release upload URL.")
            val assetUrl = "$rawUploadUrl?name=${URLEncoder.encode("project-source.zip", StandardCharsets.UTF_8.name())}"
            val uploaded = uploadBinary(assetUrl, sourceZip)
            val assetId = uploaded.optLong("id", -1L)
            val remoteSize = uploaded.optLong("size", -1L)
            if (assetId <= 0L || remoteSize != sourceZip.length() || uploaded.optString("name") != "project-source.zip") {
                throw IOException("The uploaded source asset did not match the expected name and file size. Release will remain unpublished.")
            }
            // Re-read the release and asset metadata before publishing.
            val verified = getJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/releases/$releaseId")
            val assets = verified.optJSONArray("assets") ?: JSONArray()
            val assetVerified = (0 until assets.length()).map { assets.getJSONObject(it) }.any {
                it.optLong("id") == assetId && it.optLong("size") == sourceZip.length() && it.optString("name") == "project-source.zip"
            }
            if (!assetVerified) throw IOException("GitHub did not verify the complete source asset. Release will remain unpublished.")
            val published = patchJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/releases/$releaseId", JSONObject().put("draft", false))
            if (published.optBoolean("draft", true)) throw IOException("GitHub did not publish the release. Do not launch a duplicate build; refresh this job.")
            return PublishedBuildRelease(tag, releaseId, published.optString("html_url"), assetId, remoteSize)
        } catch (error: Exception) {
            // Keep the draft so the user can inspect/retry safely; never publish a partial asset.
            throw error
        }
    }

    suspend fun findWorkflowRun(tag: String): WorkflowRunState? {
        val runs = getJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/actions/runs?event=release&per_page=100")
            .optJSONArray("workflow_runs") ?: JSONArray()
        val target = (0 until runs.length()).map { runs.getJSONObject(it) }.firstOrNull { run ->
            val display = run.optString("display_title", "")
            val name = run.optString("name", "")
            val branch = run.optString("head_branch", "")
            run.optString("event") == "release" && (display.contains(tag) || name.contains(tag) || branch == tag)
        } ?: return null
        return runState(target)
    }

    suspend fun getWorkflowRun(runId: Long): WorkflowRunState {
        val run = getJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/actions/runs/$runId")
        return runState(run)
    }

    suspend fun getArtifacts(runId: Long): List<ArtifactInfo> {
        val arr = getJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/actions/runs/$runId/artifacts?per_page=100").optJSONArray("artifacts") ?: JSONArray()
        return (0 until arr.length()).map { i -> arr.getJSONObject(i) }.map {
            ArtifactInfo(it.optLong("id"), it.optString("name"), it.optLong("size_in_bytes"), it.optBoolean("expired"))
        }
    }

    suspend fun downloadArtifact(artifactId: Long, destination: File) {
        downloadTo(apiUrl("/repos/${segment(settings.owner)}/${segment(settings.repository)}/actions/artifacts/$artifactId/zip"), destination, "application/vnd.github+json")
    }

    suspend fun downloadRunLogs(runId: Long, destination: File) {
        downloadTo(apiUrl("/repos/${segment(settings.owner)}/${segment(settings.repository)}/actions/runs/$runId/logs"), destination, "application/vnd.github+json")
    }

    suspend fun cancelWorkflowRun(runId: Long) {
        postJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/actions/runs/$runId/cancel", JSONObject())
    }

    suspend fun deleteTemporaryRelease(releaseId: Long, tag: String): String {
        var releaseDeleted = false
        try {
            deleteJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/releases/$releaseId")
            releaseDeleted = true
        } catch (error: GitHubApiException) {
            if (error.statusCode != 404) throw error
        }
        var tagDeleted = false
        try {
            deleteJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/git/refs/tags/${segment(tag)}")
            tagDeleted = true
        } catch (error: GitHubApiException) {
            if (error.statusCode != 404) throw error
        }
        return "Release deleted: $releaseDeleted. Tag deleted: $tagDeleted. Service backups/logs may retain copies for some time."
    }

    private suspend fun runState(run: JSONObject): WorkflowRunState {
        val header = WorkflowRunParser.parse(run)
        val runId = header.runId
        val jobs = if (runId > 0L) getJson("/repos/${segment(settings.owner)}/${segment(settings.repository)}/actions/runs/$runId/jobs?per_page=100").optJSONArray("jobs") ?: JSONArray() else JSONArray()
        val steps = mutableListOf<WorkflowStep>()
        var currentStep: String? = null
        for (i in 0 until jobs.length()) {
            val job = jobs.getJSONObject(i)
            val jobSteps = job.optJSONArray("steps") ?: JSONArray()
            for (j in 0 until jobSteps.length()) {
                val step = jobSteps.getJSONObject(j)
                val status = step.optString("status", "unknown")
                val title = step.optString("name", "Build step")
                steps += WorkflowStep(title, status, step.optString("conclusion").takeIf { it.isNotBlank() && it != "null" })
                if (status == "in_progress") currentStep = title
            }
        }
        return WorkflowRunState(
            runId = runId,
            status = header.status,
            conclusion = header.conclusion,
            runUrl = header.runUrl,
            displayTitle = header.displayTitle,
            createdAt = header.createdAt,
            currentStep = currentStep,
            steps = steps
        )
    }

    private suspend fun getJson(path: String): JSONObject = requestJson("GET", apiUrl(path), null)
    private suspend fun postJson(path: String, body: JSONObject): JSONObject = requestJson("POST", apiUrl(path), body)
    private suspend fun putJson(path: String, body: JSONObject): JSONObject = requestJson("PUT", apiUrl(path), body)
    private suspend fun patchJson(path: String, body: JSONObject): JSONObject = requestJson("PATCH", apiUrl(path), body)
    private suspend fun deleteJson(path: String) { requestJson("DELETE", apiUrl(path), null) }

    private suspend fun requestJson(method: String, url: String, json: JSONObject?): JSONObject = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        require(token.isNotBlank()) { "No GitHub token is configured." }
        val builder = Request.Builder().url(url)
            .header("Accept", "application/vnd.github+json")
            .header("Authorization", "Bearer $token")
            .header("X-GitHub-Api-Version", apiVersion)
            .header("User-Agent", "AI-APK-Builder-Pro/1.0")
        when (method) {
            "GET" -> builder.get()
            "POST" -> builder.post((json?.toString() ?: "{}").toRequestBody(JSON_TYPE))
            "PUT" -> builder.put((json?.toString() ?: "{}").toRequestBody(JSON_TYPE))
            "PATCH" -> builder.patch((json?.toString() ?: "{}").toRequestBody(JSON_TYPE))
            "DELETE" -> builder.delete()
            else -> throw IllegalArgumentException("Unsupported HTTP method")
        }
        http.newCall(builder.build()).execute().use { response ->
            response.header("X-RateLimit-Remaining")?.toIntOrNull()?.let { lastRateLimit = it }
            val bodyText = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = runCatching { JSONObject(bodyText).optString("message", response.message) }.getOrDefault(response.message)
                throw GitHubApiException(response.code, message)
            }
            if (bodyText.isBlank()) JSONObject() else runCatching { JSONObject(bodyText) }.getOrElse { JSONObject().put("raw", bodyText.take(1000)) }
        }
    }

    private suspend fun uploadBinary(url: String, file: File): JSONObject = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        val body = object : RequestBody() {
            override fun contentType() = "application/zip".toMediaType()
            override fun contentLength(): Long = file.length()
            override fun writeTo(sink: BufferedSink) {
                file.inputStream().buffered().use { input ->
                    val buffer = ByteArray(64 * 1024)
                    while (true) {
                        val n = input.read(buffer)
                        if (n < 0) break
                        sink.write(buffer, 0, n)
                    }
                }
            }
        }
        val request = Request.Builder().url(url)
            .header("Accept", "application/vnd.github+json")
            .header("Authorization", "Bearer $token")
            .header("X-GitHub-Api-Version", apiVersion)
            .header("User-Agent", "AI-APK-Builder-Pro/1.0")
            .post(body).build()
        http.newCall(request).execute().use { response ->
            response.header("X-RateLimit-Remaining")?.toIntOrNull()?.let { lastRateLimit = it }
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                val message = runCatching { JSONObject(text).optString("message", response.message) }.getOrDefault(response.message)
                throw GitHubApiException(response.code, message)
            }
            JSONObject(text)
        }
    }

    private suspend fun downloadTo(url: String, destination: File, accept: String) = kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
        require(token.isNotBlank()) { "No GitHub token is configured." }
        destination.parentFile?.mkdirs()
        val request = Request.Builder().url(url)
            .header("Accept", accept)
            .header("Authorization", "Bearer $token")
            .header("X-GitHub-Api-Version", apiVersion)
            .header("User-Agent", "AI-APK-Builder-Pro/1.0")
            .get().build()
        val temp = File(destination.parentFile, destination.name + ".part")
        try {
            http.newCall(request).execute().use { response ->
                response.header("X-RateLimit-Remaining")?.toIntOrNull()?.let { lastRateLimit = it }
                if (!response.isSuccessful) {
                    val message = response.body?.string()?.let { runCatching { JSONObject(it).optString("message") }.getOrDefault(response.message) } ?: response.message
                    throw GitHubApiException(response.code, message)
                }
                val body = response.body ?: throw IOException("GitHub returned an empty download body.")
                body.byteStream().buffered().use { input -> temp.outputStream().buffered().use { output -> input.copyTo(output, 64 * 1024) } }
                if (temp.length() <= 0) throw IOException("GitHub returned an empty artifact or log download.")
            }
            if (destination.exists() && !destination.delete()) throw IOException("Could not replace the previous temporary download.")
            if (!temp.renameTo(destination)) throw IOException("Could not finish saving the download to app storage.")
        } catch (error: Exception) {
            temp.delete()
            throw error
        }
    }

    private fun segment(value: String): String = java.net.URLEncoder.encode(value, StandardCharsets.UTF_8.name()).replace("+", "%20")

    companion object {
        const val SECRET_GITHUB_TOKEN = "github_token"
        private val JSON_TYPE = "application/json; charset=utf-8".toMediaType()
    }
}
