package com.aipkgbuilder.pro.worker

import android.content.Context
import androidx.work.CoroutineWorker
import androidx.work.WorkerParameters
import com.aipkgbuilder.pro.data.BuilderDatabase
import com.aipkgbuilder.pro.github.GitHubClient
import com.aipkgbuilder.pro.github.GitHubSettings
import com.aipkgbuilder.pro.github.BuildStateMapper
import com.aipkgbuilder.pro.security.SecureSecrets

/** Passive recovery poller. Credentials are read from encrypted storage, never WorkManager input data. */
class BuildStatusWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {
    override suspend fun doWork(): Result {
        val prefs = applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val owner = prefs.getString(KEY_OWNER, null).orEmpty()
        val repository = prefs.getString(KEY_REPO, null).orEmpty()
        val branch = prefs.getString(KEY_BRANCH, "main").orEmpty()
        val token = SecureSecrets(applicationContext).get(GitHubClient.SECRET_GITHUB_TOKEN).orEmpty()
        if (owner.isBlank() || repository.isBlank() || token.isBlank()) return Result.success()
        val settings = runCatching { GitHubSettings(owner, repository, branch).also { it.validate() } }.getOrNull() ?: return Result.failure()
        return try {
            val dao = BuilderDatabase.get(applicationContext).builderDao()
            // The pending tag set survives process death; each tag resolves to its own database row.
            val tags = applicationContext.getSharedPreferences("builder_runtime", Context.MODE_PRIVATE)
                .getStringSet("pending_release_tags", emptySet()).orEmpty().toList()
            if (tags.isEmpty()) return Result.success()
            val client = GitHubClient(applicationContext, settings, token)
            for (tag in tags) {
                val attempt = dao.getAttemptByTag(tag) ?: continue
                val state = client.findWorkflowRun(tag) ?: continue
                val status = BuildStateMapper.fromRemote(state.status, state.conclusion)
                val currentAttempt = attempt.copy(
                    workflowRunId = state.runId,
                    status = status,
                    completedAt = if (state.status == "completed") System.currentTimeMillis() else null,
                    message = state.currentStep ?: state.conclusion ?: state.status
                )
                dao.upsertAttempt(currentAttempt)
                val project = dao.getProject(attempt.projectId) ?: continue
                dao.upsertProject(project.copy(
                    workflowRunId = state.runId,
                    currentStatus = status,
                    lastMessage = currentAttempt.message
                ))
                if (status in setOf("SUCCEEDED", "FAILED")) {
                    val updatedTags = tags.toMutableSet().apply { remove(tag) }
                    applicationContext.getSharedPreferences("builder_runtime", Context.MODE_PRIVATE)
                        .edit().putStringSet("pending_release_tags", updatedTags).apply()
                }
            }
            Result.success()
        } catch (error: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    companion object {
        const val PREFS = "builder_settings"
        const val KEY_OWNER = "github_owner"
        const val KEY_REPO = "github_repo"
        const val KEY_BRANCH = "github_branch"
    }
}
