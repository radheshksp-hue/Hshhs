package com.aipkgbuilder.pro.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface BuilderDao {
    @Query("SELECT * FROM projects ORDER BY createdAt DESC")
    fun observeProjects(): Flow<List<ProjectEntity>>

    @Query("SELECT * FROM projects WHERE id = :id LIMIT 1")
    suspend fun getProject(id: String): ProjectEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertProject(project: ProjectEntity)

    @Query("DELETE FROM projects WHERE id = :id")
    suspend fun deleteProject(id: String)

    @Query("SELECT * FROM build_attempts ORDER BY startedAt DESC")
    fun observeBuildAttempts(): Flow<List<BuildAttemptEntity>>

    @Query("SELECT * FROM build_attempts WHERE projectId = :projectId ORDER BY attemptNumber DESC")
    suspend fun getAttemptsForProject(projectId: String): List<BuildAttemptEntity>

    @Query("SELECT * FROM build_attempts WHERE releaseTag = :tag LIMIT 1")
    suspend fun getAttemptByTag(tag: String): BuildAttemptEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsertAttempt(attempt: BuildAttemptEntity)

    @Query("DELETE FROM build_attempts WHERE projectId = :projectId")
    suspend fun deleteAttemptsForProject(projectId: String)
}
