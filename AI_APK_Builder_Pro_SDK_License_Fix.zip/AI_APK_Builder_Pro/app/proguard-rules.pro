# Keep JSON parsing and Room annotations available when minification is later enabled.
-keepattributes *Annotation*
-keep class com.aipkgbuilder.pro.data.** { *; }
